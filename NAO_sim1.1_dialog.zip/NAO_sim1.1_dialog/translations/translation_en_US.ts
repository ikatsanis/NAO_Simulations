<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hello. My name is NAO. Wellcome to our game!</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello. My name is NAO. Wellcome to our game!</translation>
        </message>
        <message>
            <source>Hello John. My name is NAO. Wellcome to our game!</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello John. My name is NAO. Wellcome to our game!</translation>
        </message>
        <message>
            <source>Hello and wellcome. My name is NAO!</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello and wellcome. My name is NAO!</translation>
        </message>
        <message>
            <source>Hello and wellcome.</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello and wellcome.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Welcome back my little friend.</source>
            <comment>Text</comment>
            <translation type="unfinished">Welcome back my little friend.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Tap my head to begin.</source>
            <comment>Text</comment>
            <translation type="obsolete">Tap my head to begin.</translation>
        </message>
        <message>
            <source>Tap my head to start.</source>
            <comment>Text</comment>
            <translation type="obsolete">Tap my head to start.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Please, tap my head to start.</source>
            <comment>Text</comment>
            <translation type="unfinished">Please, tap my head to start.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hoorey!! Let's begin!!!</source>
            <comment>Text</comment>
            <translation type="obsolete">Hoorey!! Let's begin!!!</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Great!! Let's begin!!!</source>
            <comment>Text</comment>
            <translation type="unfinished">Great!! Let's begin!!!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>I will ask you some questions and you should answer.</source>
            <comment>Text</comment>
            <translation type="obsolete">I will ask you some questions and you should answer.</translation>
        </message>
        <message>
            <source>You will have a converstation with me. You should start first!</source>
            <comment>Text</comment>
            <translation type="obsolete">You will have a converstation with me. You should start first!</translation>
        </message>
        <message>
            <source>You should start first!</source>
            <comment>Text</comment>
            <translation type="obsolete">You should start first!</translation>
        </message>
        <message>
            <source>We'll have a conversation! You should start first!</source>
            <comment>Text</comment>
            <translation type="obsolete">We'll have a conversation! You should start first!</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>We'll have a conversation!</source>
            <comment>Text</comment>
            <translation type="unfinished">We'll have a conversation!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Ready? Tap my head to begin.</source>
            <comment>Text</comment>
            <translation type="obsolete">Ready? Tap my head to begin.</translation>
        </message>
        <message>
            <source>Goobye!!</source>
            <comment>Text</comment>
            <translation type="obsolete">Goobye!!</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Speak to me and I'll speak back to you!</source>
            <comment>Text</comment>
            <translation type="unfinished">Speak to me and I'll speak back to you!</translation>
        </message>
    </context>
</TS>
