<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello and wellcome. My name is NAO.</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello and wellcome. My name is NAO.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>I will be your partner for the next hours</source>
            <comment>Text</comment>
            <translation type="obsolete">I will be your partner for the next hours</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I will be your partner for the next few hours</source>
            <comment>Text</comment>
            <translation type="unfinished">I will be your partner for the next few hours</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Together, we will play, talk and learn new things! </source>
            <comment>Text</comment>
            <translation type="unfinished">Together, we will play, talk and learn new things! </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>To show me that you are here, touch my right arm!</source>
            <comment>Text</comment>
            <translation type="unfinished">To show me that you are here, touch my right arm!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Brilliant. Let's get to know each other!</source>
            <comment>Text</comment>
            <translation type="unfinished">Brilliant. Let's get to know each other!</translation>
        </message>
    </context>
</TS>
