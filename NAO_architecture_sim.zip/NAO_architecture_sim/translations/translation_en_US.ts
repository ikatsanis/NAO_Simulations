<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Touch my hand to know that you are here.</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my hand to know that you are here.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Tap my head to know that you are here.</source>
            <comment>Text</comment>
            <translation type="unfinished">Tap my head to know that you are here.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Great!Glad that you are here!</source>
            <comment>Text</comment>
            <translation type="obsolete">Great!Glad that you are here!</translation>
        </message>
        <message>
            <source>Great. Glad that you are here!</source>
            <comment>Text</comment>
            <translation type="obsolete">Great. Glad that you are here!</translation>
        </message>
        <message>
            <source>Great. Let's explore the area!</source>
            <comment>Text</comment>
            <translation type="obsolete">Great. Let's explore the area!</translation>
        </message>
        <message>
            <source>Let's explore the area!</source>
            <comment>Text</comment>
            <translation type="obsolete">Let's explore the area!</translation>
        </message>
        <message>
            <source>Let's explore the area</source>
            <comment>Text</comment>
            <translation type="obsolete">Let's explore the area</translation>
        </message>
        <message>
            <source>Great!Let's explore the area</source>
            <comment>Text</comment>
            <translation type="obsolete">Great!Let's explore the area</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Great! I will now explore the area!</source>
            <comment>Text</comment>
            <translation type="unfinished">Great! I will now explore the area!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Lets explore the area!</source>
            <comment>Text</comment>
            <translation type="obsolete">Lets explore the area!</translation>
        </message>
        <message>
            <source>Let's explore the area!</source>
            <comment>Text</comment>
            <translation type="obsolete">Let's explore the area!</translation>
        </message>
        <message>
            <source>I have reached my destination</source>
            <comment>Text</comment>
            <translation type="obsolete">I have reached my destination</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>This item should be removed!</source>
            <comment>Text</comment>
            <translation type="unfinished">This item should be removed!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>I've reached my destination!</source>
            <comment>Text</comment>
            <translation type="obsolete">I've reached my destination!</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Yes. The item has been removed!</source>
            <comment>Text</comment>
            <translation type="unfinished">Yes. The item has been removed!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I will continue the exploration!</source>
            <comment>Text</comment>
            <translation type="unfinished">I will continue the exploration!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (5)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I completed my exploration!</source>
            <comment>Text</comment>
            <translation type="unfinished">I completed my exploration!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (6)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Interaction is safe!</source>
            <comment>Text</comment>
            <translation type="unfinished">Interaction is safe!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (7)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Goodye for now</source>
            <comment>Text</comment>
            <translation type="obsolete">Goodye for now</translation>
        </message>
    </context>
</TS>
